<?php

echo "<br>Plugin Inline: 1.0";

if($update["inline_query"])
{
$inline = $update["inline_query"]["id"];
$msg = $update["inline_query"]["query"];
$userID = $update["inline_query"]["from"]["id"];
$username = $update["inline_query"]["from"]["username"];
$name = $update["inline_query"]["from"]["first_name"];
$numero = $update["message"]["contact"]["phone_number"];

$google = str_replace(" ", "+", $msg);

$tastiera[] = array(
array(
"text" => "$msg ↗️",
"url" => "http://google.com/search?q=$google"
)
);

$csi = array(
'inline_keyboard' => $tastiera);

$array = array(
"Sai perchè le <b>tende</b> piangono? \nPerchè sono <b>da sole</b>!",
"Sai perchè Superman porta I vestiti <b>attillati</b>? \nPerchè porta una <b>s</b>!",
"Sai cosa dice un <b>termometro</b> pessimista? \nNon sono in <b>grado</b>!",
"L'insalata <b>russa</b> e il pomodoro non <b>dorme</b>",
"Sai perchè non uso camicie <b>di lino</b>? \nPerchè sono un bo- ah no, perchè <b>lino</b> non me le presta :(",
"Volevo regalarti una camicia di <b>Armani</b>, ma mi dispiaceva rimanerlo in <b>canottiera</b>",
"Come si uccide un <b>orologiaio</b>? \nSemplice! <b>col-pendolo</b>!",
"Sai perchè i libri sentono sempre <b>caldo</b>? \nPerchè hanno la <b>copertina</b>!",
"Qual è la città preferita dei <b>ragni</b>? \n<b>Mosca</b>!",
"Sai perchè le bambine piccole non possono andare a comprare gli occhiali <b>da sole</b>? \nPerchè devono essere <b>accompagnate</b> dai genitori!",
"Ma le rose senza <b>spine</b> vanno a <b>batterie</b>?",
"Ieri ho litigato con la mia <b>stampante</b>, così le ho detto 'Ueee, abbassa il <b>toner</b>'",
"Sapete chi era <b>Poseidone</b>? \n\n\n<b>Nettuno</b>!",
"Sai cosa fa un canguro <b>nero</b> su uno sfondo <b>bianco</b>? \n<b>Risalta</b>",
"Cosa fa un <b>idiota</b> al <b>telefono</b>? \n<b>Telefona</b> il suo amico per chiedergli il suo <b>numero</b>",
"Che <b>tempo</b> è <b>studiare</b>? \n<b>Tempo</b> perso!",
"Che <b>tempo</b> è <b>pioverà</b>? \n (È un) brutto tempo!",
"'Pierino, cos'è un temporale?' \n-Sono delle nubi, che spaventate dai tuoni, si mettono a piangere-",
"'Dottore come è andata l'operazione di mio marito?' \n-Beh...- \n'Posso parlare con lui?' \n-Ha una tavola ouija?-",
"Quando un uomo apre la portiera della <b>macchina</b> alla propria <b>donna</b>... _Significa che una <b>delle due</b> è nuova!",
"Mi raccomando, non devi mai fidarti di un americano... ti <b>USA</b>",
"Sai perchè in America fa <b>freddo</b>? Perchè l'hanno <b>scoperta</b>",
"'Un dino' 'due dini' 'tre dini' _-ma che fai?- 'faccio il conta-<b>dino</b>'",
"Sai cosa fanno due Buddha fuori la discoteca? _I BuddhaFuori",
"'Mi scusi, per andare al <b>cimitero</b> dove devo prendere l'autobus?' _In <b>faccia</b>",
"La <b>tuta</b> di Batman? _La Bat-<b>tuta</b>!",
"La differenza tra <b>Manybot</b> e la <b>merda</b>? _<b>Nessuna</b> ^-^",
"Sai cosa dice un <b>vulcano</b> appena nato? _Voglio la <b>magma</b>",
"Sai perchè <b>Hitler</b> si è suicidato? _Perchè ha visto la <b>bolletta</b> del <b>gas</b>",
"Sai cosa dice un <b>paracadute</b> al paracadutista? _'Non so se mi <b>spiego</b>'",
"Sulla riva di un fiume un uomo <b>pesca</b> _L'altro <b>mela</b>",
"Sai cosa dice una <b>mosca</b> quando vede un cancello chiuso? '<b>Mosca-valco</b>'",
"Sai cosa dice un <b>elefenate</b> davanti ad un frigo pieno di coca-cola? '<b>E-le-fante?</b>'",
"Sulla riva di un fiume un uomo <b>pesca</b> _L'altro <b>mela</b>",
"Sai cosa dice una <b>mosca</b> quando vede un cancello chiuso? '<b>Mosca-valco</b>'",
"Sai cosa dice un <b>elefenate</b> davanti ad un frigo pieno di coca-cola? '<b>E-le-fante?</b>'",
"Cosa fa una <b>sardina</b> dopo la doccia? _Si <b>acciuga</b>",
"Perchè Mosè <b>divise</b> le acque? _Perchè c'era chi la voleva <b>gassata</b> e chi <b>naturale</b>!",
"Sai qual è il <b>cane</b> più cattivo? _La <b>can</b>-aglia!",
"Un uomo <b>entra</b> in un caffè... _<b>SPLASH!</b>"
);
shuffle($array);
$testo_casuale = $array[0];

$json = array(
//prima riga risultati
array(
'type' => 'article',
'id' => 'kakfieokakfieofo',
'title' => 'Cerca su Google',
'description' => "Cerca su Google quello che vuoi!",
'message_text' => "Ecco quel che ho trovato su internet riguardo alla parola/frase '*$msg*'",
'reply_markup' => $csi,
'parse_mode' => 'Markdown'
),
$json = array(
//seconda riga risultati
array(
'type' => 'article',
'id' => 'kakfieokahahahsheo',
'title' => 'Freddura',
'description' => "Jack raccontami una barzelletta🤡",
'message_text' => "$testo_casuale",
'parse_mode' => 'HTML'
),
);


$json = json_encode($json);
$args = array(
'inline_query_id' => $inline,
'results' => $json,
'cache_time' => 5
);
$r = new HttpRequest("post", "https://api.telegram.org/$api/answerInlineQuery", $args);

}



