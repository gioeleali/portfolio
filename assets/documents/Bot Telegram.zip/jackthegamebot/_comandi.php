<?php






//comandi del bot

if($msg == "/start")
{
$menu[] = array(
array( 
"text" => "Il mio creatore", 
"url" => "http://telegram.me/JackTheGame"),
);
$menu[] = array(
array(
"text" => "Il mio canale", 
"url" => "http://telegram.me/JackTheGameBotChannel"),
);
sm($chatID, "Ciao $nome $cognome, io sono Jack, un bot sviluppato in PHP, il mio creatore è: @JackTheGame, ti lascio il nick, caso mai volessi chiedergli qualcosa.
Non ti dimenticare di seguire il mio canale: @JackTheGameBotChannel per restare aggiornato su ogni mio nuovo comando!", $menu, 'HTML', false, false, true); 
}

if($msg == "Giorno" or $msg == "Buongiorno Jack" or $msg == "Buongiorno" or $msg == "Giorno Jack")
{
sm($chatID, "Buongiorno $nome 🙂");
}

if($msg == "Notte" or $msg == "Buonanotte Jack" or $msg == "Buonanotte" or $msg == "Notte Jack")
{
sm($chatID, "Buonanotte $nome 😪");
}

if($msg == "Ciao" or $msg == "ciao" or $msg == "Ciao Jack" or $msg == "ciao jack")
{
sm($chatID, "Ciao $nome");
}

if($msg == "/myinfo")
{
if($cognome == null)
{
$cognome = "Nessun cognome.";
}
if($username == null)
{
$username = "Nessun username.";
}
sm($chatID, "<b>Questi sono i tuoi dati:</b>
  <b>ID:</b> <i>$userID</i>
  <b>Nome:</b> <i>$nome</i>
  <b>Cognome:</b> <i>$cognome</i>
  <b>Username:</b> @$username");
}

if($msg == "Porcoddio" or $msg == "Porcodio" or $msg == "Porca madonna" or $msg == "Diocane" or $msg == "Diomerda" or $msg == "Dio merda")
{
sm($chatID, "Cazzo bestemmi porcoddio");
}


if($msg == "jack raccontami una barzelletta" or $msg == "Jack raccontami una barzelletta")
{
$array = array(
"Sai perchè le <b>tende</b> piangono? \nPerchè sono <b>da sole</b>!",
"Sai perchè Superman porta I vestiti <b>attillati</b>? \nPerchè porta una <b>s</b>!",
"Sai cosa dice un <b>termometro</b> pessimista? \nNon sono in <b>grado</b>!",
"L'insalata <b>russa</b> e il pomodoro non <b>dorme</b>",
"Sai perchè non uso camicie <b>di lino</b>? \nPerchè sono un bo- ah no, perchè <b>lino</b> non me le presta :(",
"Volevo regalarti una camicia di <b>Armani</b>, ma mi dispiaceva rimanerlo in <b>canottiera</b>",
"Come si uccide un <b>orologiaio</b>? \nSemplice! <b>col-pendolo</b>!",
"Sai perchè i libri sentono sempre <b>caldo</b>? \nPerchè hanno la <b>copertina</b>!",
"Qual è la città preferita dei <b>ragni</b>? \n<b>Mosca</b>!",
"Sai perchè le bambine piccole non possono andare a comprare gli occhiali <b>da sole</b>? \nPerchè devono essere <b>accompagnate</b> dai genitori!",
"Ma le rose senza <b>spine</b> vanno a <b>batterie</b>?",
"Ieri ho litigato con la mia <b>stampante</b>, così le ho detto 'Ueee, abbassa il <b>toner</b>'",
"Sapete chi era <b>Poseidone</b>? \n\n\n<b>Nettuno</b>!",
"Sai cosa fa un canguro <b>nero</b> su uno sfondo <b>bianco</b>? \n<b>Risalta</b>",
"Cosa fa un <b>idiota</b> al <b>telefono</b>? \n<b>Telefona</b> il suo amico per chiedergli il suo <b>numero</b>",
"Che <b>tempo</b> è <b>studiare</b>? \n<b>Tempo</b> perso!",
"Che <b>tempo</b> è <b>pioverà</b>? \n (È un) brutto tempo!",
"'Pierino, cos'è un temporale?' \n-Sono delle nubi, che spaventate dai tuoni, si mettono a piangere-",
"'Dottore come è andata l'operazione di mio marito?' \n-Beh...- \n'Posso parlare con lui?' \n-Ha una tavola ouija?-",
"Quando un uomo apre la portiera della <b>macchina</b> alla propria <b>donna</b>... _Significa che una <b>delle due</b> è nuova!",
"Mi raccomando, non devi mai fidarti di un americano... ti <b>USA</b>",
"Sai perchè in America fa <b>freddo</b>? Perchè l'hanno <b>scoperta</b>",
"'Un dino' 'due dini' 'tre dini' _-ma che fai?- 'faccio il conta-<b>dino</b>'",
"Sai cosa fanno due Buddha fuori la discoteca? _I BuddhaFuori",
"'Mi scusi, per andare al <b>cimitero</b> dove devo prendere l'autobus?' _In <b>faccia</b>",
"La <b>tuta</b> di Batman? _La Bat-<b>tuta</b>!",
"La differenza tra <b>Manybot</b> e la <b>merda</b>? _<b>Nessuna</b> ^-^",
"Sai cosa dice un <b>vulcano</b> appena nato? _Voglio la <b>magma</b>",
"Sai perchè <b>Hitler</b> si è suicidato? _Perchè ha visto la <b>bolletta</b> del <b>gas</b>",
"Sai cosa dice un <b>paracadute</b> al paracadutista? _'Non so se mi <b>spiego</b>'",
"Sulla riva di un fiume un uomo <b>pesca</b> _L'altro <b>mela</b>",
"Sai cosa dice una <b>mosca</b> quando vede un cancello chiuso? '<b>Mosca-valco</b>'",
"Sai cosa dice un <b>elefenate</b> davanti ad un frigo pieno di coca-cola? '<b>E-le-fante?</b>'",
"Sulla riva di un fiume un uomo <b>pesca</b> _L'altro <b>mela</b>",
"Sai cosa dice una <b>mosca</b> quando vede un cancello chiuso? '<b>Mosca-valco</b>'",
"Sai cosa dice un <b>elefenate</b> davanti ad un frigo pieno di coca-cola? '<b>E-le-fante?</b>'",
"Cosa fa una <b>sardina</b> dopo la doccia? _Si <b>acciuga</b>",
"Perchè Mosè <b>divise</b> le acque? _Perchè c'era chi la voleva <b>gassata</b> e chi <b>naturale</b>!",
"Sai qual è il <b>cane</b> più cattivo? _La <b>can</b>-aglia!",
"Un uomo <b>entra</b> in un caffè... _<b>SPLASH!</b>"
);
shuffle($array);
$testo_casuale = $array[0];
sm($chatID, "$testo_casuale");
}

if($msg == "Sasso" or $msg == "sasso")
{
$sasso = array(
"Carta, <b>ho vinto io :P</b>",
"Sasso, <b>pareggio :/</b>",
"Forbici, <b>ho perso :c</b>"
);
shuffle($array);
$sasso = $array[0];
sm($chatID, "$sasso");
}

if($msg == "Carta" or $msg == "carta")
{
$carta = array(
"Carta, <b>pareggio :/</b>",
"Sasso, <b>ho perso </b>:c",
"Forbici,  <b>ho vinto io :P</b>"
);
shuffle($array);
$carta = $array[0];
sm($chatID, "$carta");
}

if($msg == "Forbici" or $msg == "forbici")
{
$forbici = array(
"Carta, <b>ho perso :c</b>",
"Sasso, <b>ho vinto io :P</b>",
"Forbici, <b>pareggio :/</b>"
);
shuffle($array);
$forbici = $array[0];
sm($chatID, "$forbici");
}



//comandi per jack

if(strpos($msg, "/setlist")=== 0 and $userID == 152355261) 
{
   $e = explode(" ", $msg, 2);
	$welcome = $e[1]; 
	
	mkdir("benvenuti");
	mkdir("benvenuti/gruppi");
	file_put_contents("benvenuti/gruppi/$chatID.txt", $welcome);
	
	sm($chatID, "Lista Aggiornata");
} 

if($msg == "/list")
{
	
	$benvenutodelgruppo = file_get_contents("benvenuti/gruppi/$chatID.txt");
	
	sm($chatID, $benvenutodelgruppo);

} 