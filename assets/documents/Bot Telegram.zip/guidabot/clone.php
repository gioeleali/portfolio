<?php

echo "<br>Plugin Clone 1.0 by @AVPluginBot";

$linkwb = "https://gioie24.altervista.org/gioie24bot/index.php";

//Dove c'è $linkwb = nelle virgolette metti il tuo sito con https

if($msg == "/clone")
{
mkdir("DATA");
mkdir("DATA/COPY");
file_put_contents("DATA/COPY/copy $userID", "ok");
sm($chatID, "Ok, ora inviami il token del tuo bot, oppure usa /cancel per annullare l'operazione"); 
exit;
}

if($msg == "/cancel")
{
sm($chatID, "Annullato!");
unlink("DATA/COPY/copy $userID");
}

if($msg)
{
$getid = file_get_contents("DATA/COPY/copy $userID");
if($getid == "ok")
{
global $token;
$r = new HttpRequest("POST", "https://api.telegram.org/bot$msg/setWebhook?url=$linkwb?api=bot$msg");
sm($chatID, "Ok, se il token è giusto allora ho clonato il tuo bot correttamente.");
unlink("DATA/COPY/copy $userID");
}
}

?>