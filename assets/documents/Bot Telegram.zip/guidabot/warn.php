﻿<?php

echo "<br>Plugin Warn 1.0 by @AVPlugin";

//Plugin distrubuito da: @AVPlugin
//Plugin creato da: @xSamumine

if ($msg)
  {
    $args   = array(
        'chat_id' => $chatID
    );
    $add    = new HttpRequest("get", "https://api.telegram.org/$api/getChatAdministrators", $args);
    $ris    = $add->getResponse();
    $admins = json_decode($ris, true);
    foreach ($admins['result'] as $adminsa)
      {
        if ($adminsa['user']['id'] == $userID)
            $isadmin = true;
        if ($adminsa["user"]["id"] == $userID and $adminsa["status"] == "creator")
            $isfounder = true;
      }
  }
  
if($msg)
{
	mkdir("utenti");
	$iscritti = file_get_contents("utenti/iscritti.txt");
	if(preg_match("/$userID/i",$iscritti))
	{}else{
		$file = "utenti/iscritti.txt";
		$f2 = fopen($file, 'a');
		fwrite($f2, "$userID
		");
		fclose($f2);
	}
	mkdir("utenti/$userID");
	file_put_contents("utenti/$userID/nome.txt",$nome);
	file_put_contents("utenti/$userID/cognome.txt",$cognome);
	file_put_contents("utenti/$userID/username.txt",$username);
}
  
function warn($IDwarn)
  {
    $warnmassimi = 3;
    $content     = file_get_contents('php://input');
    $update      = json_decode($content, true);
    $chatID      = $update["message"]["chat"]["id"];
    mkdir("utenti/warn");
    mkdir("utenti/warn/$chatID");
    $warnprecedenti = file_get_contents("utenti/warn/$chatID/$IDwarn.txt");
    $warntotali     = $warnprecedenti + 1;
	$nomeID = file_get_contents("utenti/$IDwarn/nome.txt");
    file_put_contents("utenti/warn/$chatID/$IDwarn.txt", $warntotali);
    if ($warntotali == $warnmassimi)
      {
        return ("L'utente $nomeID <i>($IDwarn)</i> ha raggiunto i warn massimi ($warnmassimi), quindi è stato bannato dal gruppo.");
        ban($chatID, $IDwarn);
      }
    else
      {
        return ("Ok, ho aggiunto un <b>warn</b> all'utente $nomeID <i>($IDwarn)</i>
    
    <b>Warn totali: $warntotali</b>");
      }
  }

function unwarn($IDwarn)
  {
    $content        = file_get_contents('php://input');
    $update         = json_decode($content, true);
    $chatID         = $update["message"]["chat"]["id"];
    $warnprecedenti = file_get_contents("utenti/warn/$chatID/$IDwarn.txt");
    $warntotali     = $warnprecedenti - 1;
	$nomeID = file_get_contents("utenti/$IDwarn/nome.txt");
    file_put_contents("utenti/warn/$chatID/$IDwarn.txt", $warntotali);
    return ("Ok, ho rimosso un <b>warn</b> all'utente $nomeID <i>($IDwarn)</i>
    
    <b>Warn totali: $warntotali</b>");
  }
if (stripos($msg, "!warn") === 0 and $isadmin)
  {
    $e  = explode(" ", $msg, 2);
    $ID = $e[1];
    if ($ID == null)
      {
        $ID = $update["message"]["reply_to_message"]["from"]["id"];
      }
    if ($ID == null)
      {
      }
    else
      {
        if (is_numeric($ID))
          {
            $args = array(
                'chat_id' => $chatID,
                'text' => warn($ID),
                'parse_mode' => 'HTML'
            );
            $r    = new HttpRequest("post", "https://api.telegram.org/$api/sendmessage", $args);
          }
        else
          {
            sm($chatID, "ID non numerico");
          }
      }
  }
  
if (stripos($msg, "!unwarn") === 0 and $isadmin)
  {
    $e  = explode(" ", $msg, 2);
    $ID = $e[1];
    if ($ID == null)
      {
        $ID = $update["message"]["reply_to_message"]["from"]["id"];
      }
    if ($ID == null)
      {
      }
    else
      {
        if (is_numeric($ID))
          {
            $args = array(
                'chat_id' => $chatID,
                'text' => unwarn($ID),
                'parse_mode' => 'HTML'
            );
            $r    = new HttpRequest("post", "https://api.telegram.org/$api/sendmessage", $args);
          }
        else
          {
            sm($chatID, "ID non numerico");
          }
      }
  }
  
if ($msg == "!totalwarn" and $isadmin)
  {
    $iscritti        = file_get_contents("utenti/iscritti.txt");
    $iscrittiexplode = explode("\n", $iscritti);
    foreach ($iscrittiexplode as $iscritto)
      {
        $warniscritto = file_get_contents("utenti/warn/$chatID/$iscritto.txt");
        if ($iscritto == null)
          {
          }
        else
          {
            if ($warniscritto == null or $warniscritto == "0")
              {
              }
            else
              {
                $menu[] = array(
                    array(
                        "text" => "$iscritto [$warniscritto]",
                        "callback_data" => "/totalwarnisc $iscritto"
                    )
                );
              }
          }
      }
    sm($chatID, "Ecco la lista degli utenti che hanno almeno un warn.
Clicca su un utente per vedere le sue informazioni!", $menu, 'HTML', false, false, true);
  }
  
if ($cbdata == "/totalwarninline" and $isadmin)
  {
    $iscritti        = file_get_contents("utenti/iscritti.txt");
    $iscrittiexplode = explode("\n", $iscritti);
    foreach ($iscrittiexplode as $iscritto)
      {
        $warniscritto = file_get_contents("utenti/warn/$chatID/$iscritto.txt");
        if ($iscritto == null)
          {
          }
        else
          {
            if ($warniscritto == null or $warniscritto == "0")
              {
              }
            else
              {
                $menu[] = array(
                    array(
                        "text" => "$iscritto [$warniscritto]",
                        "callback_data" => "/totalwarnisc $iscritto"
                    )
                );
              }
          }
      }
    cb_reply($cbid, "Ok!", false, $cbmid, "Ecco la lista degli utenti che hanno almeno un warn.
Clicca su un utente per vedere le sue informazioni!", $menu);
  }
  
if (stripos($cbdata, "/totalwarnisc") === 0 and $isadmin)
  {
    $e          = explode(" ", $msg, 2);
    $ID         = $e[1];
    $nomeID     = file_get_contents("utenti/$ID/nome.txt");
    $cognomeID  = file_get_contents("utenti/$ID/cognome.txt");
    $usernameID = file_get_contents("utenti/$ID/username.txt");
    $warnID     = file_get_contents("utenti/warn/$chatID/$ID.txt");
    $menu[]     = array(
        array(
            "text" => "Torna indietro",
            "callback_data" => "/totalwarninline"
        )
    );
    cb_reply($cbid, "Ok!", false, $cbmid, "ID: $ID
Nome: $nomeID
Cognome: $cognomeID
Username: $usernameID
Warn: $warnID", $menu);
  }