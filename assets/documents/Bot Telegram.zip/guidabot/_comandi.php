<?php






//comandi del bot

if($msg == "/start")
{
$menu[] = array( 
array( 
"text" => "Richiedi📥", 
"callback_data" => "Materiale"),
);
sm($chatID, "Ciao <b>$nome</b>!
Benvenuto nel bot per le richieste di @ApkTime

<i>Premi il bottone qui sotto per richiedere un'applicazione!</i>⤵️", $menu, 'HTML', false, false, true); 
}

$cbmidni = $update['message']['message_id'];

if($cbdata == "Materiale") 
{  
$menu[] = array(  
array(  
"text" => "Annulla↩",  
"callback_data" => "Indietro"),  
); 
cb_reply($cbid, "Free Post!", false, $cbmid, "ℹ<i>Inserisci il nome completo dell'applicazione desiderata, seguito dal numero della versione</i>", $menu, 'HTML', false, false, true);
mkdir("attesa");
mkdir("attesa/foto");
file_put_contents("attesa/foto/$userID.txt","attesa");
}

if($cbmidni and file_exists("attesa/foto/$userID.txt"))
{
if($username)
{
$caption = "@$username";
}else{
$caption = "<a href=\"tg://user?id=$userID\">$nome</a>";
}
$args = array(
'chat_id' => "-1001373682229",
'parse_mode' => HTML,
'text' => "Richiesta effettuata da $caption
<i>Nome Applicazione:</i> <b>$msg</b>

<a href=\"$link\">↪Link PlayStore</a>

#richiesta",
);
new HttpRequest("get", "https://api.telegram.org/$api/sendMessage", $args);

$menu[] = array(
array(
"text" => "Home🏠",
"callback_data" => "Indietro"),
);
sm($chatID, "Richiesta effettuata✅", $menu, 'HTML', false, false, true);

unlink("attesa/foto/$userID.txt");
}

if($cbdata == "Indietro")
{
unlink("attesa/foto/$userID.txt");
}



if($cbdata == "Indietro")
{
$menu[] = array( 
array( 
"text" => "Richiesta", 
"callback_data" => "Materiale"),
);
cb_reply($cbid, "🏠Menù principale", false, $cbmid, "Ciao <b>$nome</b>!
Benvenuto nel bot per le richieste di @ApkTime

<i>Premi il bottone qui sotto per richiedere un'applicazione!</i>⤵️", $menu, 'HTML', false, false, true);
}

if($msg == "/chatid")
{
sm($chatID, "$chatID");
}




