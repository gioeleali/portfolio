<?php






//comandi del bot



if($msg == "/start")
{
$menu[] = array(
array( 
"text" => "Entra in OTI", 
"url" => "http://telegram.me/OpenTelegramItalia"),
);
sm($chatID, "📢 <b>BENVENUTO IN OTI</b> 📢
la prima community italiana riguardante Telegram a 360°!!
<b>Prima di scrivere, prendi subito visione del</b> 👉 @regolamento 👈
A seguire troverai tutti i <b>link utili</b>


🎉 Scopri il nostro <b>OTI Network</b>: è una <b>rete di gruppi, canali e bot</b> gestiti sotto il segno della sicurezza, dell'affidabilità nella gestione e della totale gratuità che ci contraddistingue.
Un punto di riferimento per tutta la community, 🖊 <i>firmato OTI</i>
➡️ @OTInetwork
<i>Creato da noi, per voi.</i> <b>Qualità OTI</b> 😎


📌 <b>Bacheca della Community</b>
➡️ @bacheca


🤖 <b>I nostri bot</b>  ➖➖➖➖➖

📬 Per contattare gli admin o inviare un feedback:
➡️ @OTInetworkBot
📬 Per cercare messaggi relativi ad alcuni topic indicizzati:
➡️ @OTIindexBot (anche inline)


✳️ Funzione Tag Alert  ➖➖➖
➡️ <a href='http://telegram.me/MasterTagAlertBot'>avvia il bot</a> e segui le istruzioni


🆘 <b>Contatti utili</b>  ➖➖➖➖➖
🔹 Unban del tuo account: @spambot (oppure spam@telegram.org)
🔹 Segnalazione abusi, molestie, contenuti illegali: abuse@telegram.org
🔹 Per problemi con la sicurezza: security@telegram.org
🔹 Supporto Telegram italiano per i bug report: +42439 (impostazioni ➡️ fai una domanda)
🔹 Supporto per i bot: @BotSupport (solo in inglese)


#️⃣ <i>Hashtag frequenti</i>  ➖➖➖
#proposta #messaggi #bot #canali #username #supergruppi #gruppi #chatsegrete #spam #sondaggio #link #admin #avviso #novità #changelog #utente #notifiche #cache #classifica #plus #mobogram #client #desktop #inline #TDesktop

🚀 Aiutaci a far crescere la community! <a href='http://www.telegramitalia.it/open-telegram-italia'>VOTACI QUI</a>", $menu, 'HTML', false, false, true);
}