<?php






//comandi del bot


if($msg == "/start")
{
$menu[] = array( 
array(
"text" => "📚Indirizzi",
"callback_data" => "indirizzi"),
array( 
"text" => "🗿Storia", 
"callback_data" => "storia"),
array(
"text" => "👥Contatti",
"callback_data" => "contatti"),
);
$menu[] = array( 
array(
"text" => "📘RE Argo",
"url" => "http://t.me/ArgoFamigliaBot"),
array(
"text" => "🔗Sito Web",
"url" => "http://www.davincifascetti.it"),
);
sm($chatID, "<b>I.I.S. 'Da Vinci-Fascetti'</b>

📍<i>Via Contessa Matilde, 74, 56123, Pisa (PI)</i>
☎️<i>Centralino:</i> 050888420
📠<i>Fax:</i> 050888488
📧<i>Email Istituzionale:</i> piis00800a@istruzione.it
✉<i>PEC (Posta Elettronica Certificata):</i> piis00800a@pec.istruzione.it
🏷<i>Codice meccanografico:</i> <b>PIIS00800A</b>", $menu, 'HTML', false, false, true); 
}

if($cbdata == "storia") 
{  
$menu[] = array(
array(  
"text" => "Indietro↩",  
"callback_data" => "Indietro"),  
); 
cb_reply($cbid, "Storia⤵️", false, $cbmid, "<i>L’Istituto è collocato in un’area di 43.000 metri quadri. Di questi 9.000 sono coperti da edifici che occupano un volume complessivo di di circa 85.000 metri cubi. 
Data la vastità dell’area a disposizione gli edifici sono circondati da ampi spazi verdi.
L’ITIS di Pisa dispone di numerosi laboratori ed aule speciali e di due palestre. 
All’interno dell’edificio principale si trovano la biblioteca, la sala di lettura e il centro stampa. Nell’edificio centrale è situata anche l’aula magna che è attrezzata per le proiezioni.
Le origini dell’Istituto Tecnico Industriale di Pisa risalgono agli albori del regno d’Italia quando nel 1871 fu fondata la “Scuola Tecnico-Industriale” per iniziativa del Comune di Pisa. 
Nel 1886 la scuola fu divisa in due istituti: la “Scuola Industriale” sostenuta dal Comune e la “Scuola Tecnica” sovvenzionata dallo Stato. 
Dopo varie trasformazioni nel 1908 la scuola fu riordinata e posta alle dipendenze del Ministero dell’Agricoltura, dell’Industria e del Commercio. Nel 1915 passò sotto il Ministero dell’Educazione Nazionale e fu classificata come “Regia Scuola Industriale di II grado”. Nel 1924 divenne “Regia Scuola di Tirocinio”. Nel 1926 fu riordinata come “Regio Istituto Tecnico Industriale” ed assunse la struttura che mantiene tuttora.</i>", $menu, 'HTML', false, false, true);
}

if($cbdata == "contatti") 
{  
$menu[] = array(
array(  
"text" => "Indietro↩",  
"callback_data" => "Indietro"),  
); 
cb_reply($cbid, "Contatti⤵️", false, $cbmid, "<b>Dirigente Scolastico</b>
<i>Ing. Fortunato Nardelli</i>
• preside@itispisa.gov.it

<b>D.S.G.A. – Direttore dei Servizi Generali e Amministrativi</b>
<i>Teresa Evangelista</i>
• dsga@itispisa.gov.it

<b>Segreteria Didattica</b>
<i>Assistenti amministrativi: Eleonora Cosma, Lia Fustini</i>
• didattica@itispisa.gov.it

<b>Segreteria Personale</b>
<i>Assistenti amministrativi: Patrizia Corti, Laura Bacci</i>
• personale@itispisa.gov.it

<b>Ufficio Economato</b>
<i>Assistente amministrativo: Serenella Baroncini</i>
• economato@itispisa.gov.it

<b>Ufficio Amministrativo</b>
<i>Assistente amministrativo: Stefano Cappannella</i>
• amministrazione@itispisa.gov.it

<b>Ufficio Protocollo</b>
<i>Assistente amministrativo: Camilla Braccini</i>
• protocollo@itispisa.gov.it

ℹ<i>Gli Uffici ricevono dal lunedì al sabato dalle 10.00 alle 12.00.</i>", $menu, 'HTML', false, false, true);
}

if($cbdata == "indirizzi") 
{  
$menu[] = array(
array(  
"text" => "Indietro↩",  
"callback_data" => "Indietro"),  
); 
cb_reply($cbid, "Indirizzi⤵️", false, $cbmid, "🌎<b>CHIMICA, MATERIALI E BIOTECNOLOGIE</b>
    ➥ • <a href=\"http://www.davincifascetti.it/biotecnologie-ambientali/\">BIOTECNOLOGIE AMBIENTALI</a>

💡<b>ELETTRONICA ED ELETTROTECNICA</b>
    ➥ • <a href=\"http://www.davincifascetti.it/elettronica/\">ELETTRONICA</a>
    ➥ • <a href=\"http://www.davincifascetti.it/elettrotecnica-2/\">ELETTROTECNICA</a>

💻<b>INFORMATICA E TELECOMUNICAZIONI</b>
    ➥ • <a href=\"http://www.davincifascetti.it/informatica/\">INFORMATICA</a>
    ➥ • <a href=\"http://www.davincifascetti.it/telecomunicazioni/\">TELECOMUNICAZIONI</a>

⚙<b>MECCANICA, MECCATRONICA ED ENERGIA</b>
    ➥ • <a href=\"http://www.davincifascetti.it/meccanica-e-meccatronica\">MECCANICA E MECCATRONICA</a>

✈<b>TRASPORTI E LOGISTICA</b>
    ➥ • COSTRUZIONE DEL MEZZO
        ➥ • <a href=\"http://www.davincifascetti.it/costruzioni-aeronautiche/\">COSTRUZIONI AERONAUTICHE</a>", $menu, 'HTML', false, false, true);
}



//indietro

if($cbdata == "Indietro")
{
$menu[] = array( 
array(
"text" => "📚Indirizzi",
"callback_data" => "indirizzi"),
array( 
"text" => "🗿Storia", 
"callback_data" => "storia"),
array(
"text" => "👥Contatti",
"callback_data" => "contatti"),
);
$menu[] = array( 
array(
"text" => "📘RE Argo",
"url" => "http://t.me/PortaleArgoBot"),
array(
"text" => "🔗Sito Web",
"url" => "http://www.davincifascetti.it"),
);
cb_reply($cbid, "🏠Menù principale", false, $cbmid, "<b>I.I.S. 'Da Vinci-Fascetti'</b>

📍<i>Via Contessa Matilde, 74, 56123, Pisa (PI)</i>
☎️<i>Centralino:</i> 050888420
📠<i>Fax:</i> 050888488
📧<i>Email Istituzionale:</i> piis00800a@istruzione.it
✉<i>PEC (Posta Elettronica Certificata):</i> piis00800a@pec.istruzione.it
🏷<i>Codice meccanografico:</i> <b>PIIS00800A</b>", $menu, 'HTML', false, false, true);
}