<?php






//comandi del bot


$qcp = mysql_query("select * from $tabella where not page = 'disable' and chat_id>0 group by chat_id");
$cp = mysql_num_rows($qcp);

if($msg == "/start" or $msg == "/start inline")
{
$menu[] = array(
array(
"text" => "📕 Introduzione",
"callback_data" => "introduzione"),
array(
"text" => "🕯Promessa",
"callback_data" => "promessa"),
array(
"text" => "📚 Legge",
"callback_data" => "legge"),
);
$menu[] = array(
array(
"text" => "🍁Frasi Baden Powell",
"callback_data" => "random"),
array(
"text" => "Inline mode",
"switch_inline_query" => ""),
);
sm($chatID, "<b>Ciao $nome!</b>
Benvenuto nel primo bot di <i>Telegram Italia</i> riguardante lo <b>scautismo</b>!🌳

Usa questo semplice menù per comunicare con me

Se ti vuoi confrontare con altri <b>scout e guide</b> entra nel <a href=\"https://t.me/joinchat/CWuKjEAaozkj7jV1v-MI4w\">gruppo ufficiale</a>👥

Attualmente sono iscritti al bot <b>$cp scouts</b>", $menu, 'HTML', false, false, true);
}



if($cbdata == "promessa")
{
$menu[] = array(
array(
"text" => "➰AGESCI",
"callback_data" => "promessaagesci"),
array(
"text" => "➰CNGEI",
"callback_data" => "promessacngei"),
);
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "🕯Promessa", false, $cbmid, "Vuoi visualizzare la promessa <b>AGESCI </b> o <b>CNGEI</b>?", $menu, 'HTML', false, false, true);
}



if($cbdata == "Indietro2")
{
$menu[] = array(
array(
"text" => "➰AGESCI",
"callback_data" => "promessaagesci"),
array(
"text" => "➰CNGEI",
"callback_data" => "promessacngei"),
);
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "🕯Promessa", false, $cbmid, "Vuoi visualizzare la promessa <b>AGESCI </b> o <b>CNGEI</b>?", $menu, 'HTML', false, false, true);
}



if($cbdata == "Indietro3")
{
$menu[] = array(
array(
"text" => "➰AGESCI",
"callback_data" => "leggeagesci"),
array(
"text" => "➰CNGEI",
"callback_data" => "leggecngei"),
);
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "📚Legge", false, $cbmid, "Vuoi visualizzare la legge scout <b>AGESCI </b> o <b>CNGEI</b>?", $menu, 'HTML', false, false, true);
}



if($cbdata == "promessaagesci")
{
$menu[] = array( 
array( 
"text" => "⬅ Indietro", 
"callback_data" => "Indietro2"), 
);
cb_reply($cbid, "🕯Promessa AGESCI", false, $cbmid, "<b>Promessa AGESCI</b>

<i>Con l'aiuto di Dio prometto sul mio onore di fare del mio meglio:
• per compiere il mio dovere verso Dio e verso il mio Paese
• per aiutare gli altri in ogni circostanza
• per osservare la Legge Scout.</i>", $menu, 'HTML', false, false, true);
}



if($cbdata == "promessacngei")
{
$menu[] = array( 
array( 
"text" => "⬅ Indietro", 
"callback_data" => "Indietro2"), 
);
cb_reply($cbid, "🕯Promessa CNGEI", false, $cbmid, "<b>Promessa CNGEI</b>

<i>Prometto sul mio Onore di fare del mio meglio per:
• compiere il mio dovere verso Dio, la Patria, e la Famiglia
• agire sempre con Disinteresse e Lealtà
• osservare la Legge Scout.</i>", $menu, 'HTML', false, false, true);
}



if($cbdata == "legge")
{
$menu[] = array(
array(
"text" => "➰AGESCI",
"callback_data" => "leggeagesci"),
array(
"text" => "➰CNGEI",
"callback_data" => "leggecngei"),
);
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "📚Legge", false, $cbmid, "Vuoi visualizzare la legge scout <b>AGESCI </b> o <b>CNGEI</b>?", $menu, 'HTML', false, false, true);
}


if($cbdata == "leggeagesci")
{
$menu[] = array( 
array( 
"text" => "⬅ Indietro", 
"callback_data" => "Indietro3"), 
);
cb_reply($cbid, "📚Legge Scout AGESCI", false, $cbmid, "<b>Legge Scout AGESCI</b>

<i>La Guida e lo Scout:

• pongono il loro onore nel meritare fiducia
• sono leali
• si rendono utili e aiutano gli altri
• sono amici di tutti e fratelli di ogni altra Guida e Scout
• sono cortesi
• amano e rispettano la natura
• sanno obbedire
• sorridono e cantano anche nelle difficoltà
• sono laboriosi ed economi
• sono puri di pensieri, parole ed azioni.</i>", $menu, 'HTML', false, false, true);
}



if($cbdata == "leggecngei")
{
$menu[] = array( 
array( 
"text" => "⬅ Indietro", 
"callback_data" => "Indietro3"), 
);
cb_reply($cbid, "📚Legge Scout CNGEI", false, $cbmid, "<b>Legge Scout CNGEI</b>

<i>• La Parola dell'Esploratore è sacra
• l'Esploratore è leale, forte e coraggioso
• l'Esploratore è buono e generoso
• l'Esploratore è amico di tutti e fratello di ogni altro Esploratore
• l'Esploratore è cortese e tollerante
• l'Esploratore rispetta e protegge i luoghi, gli animali e le piante
• l'Esploratore è coscientemente disciplinato
• l'Esploratore è sempre sereno, anche nelle difficoltà
• l'Esploratore è sobrio, economo, laborioso e perseverante
• l'Esploratore è puro nei pensieri, corretto nelle parole e negli atti</i>", $menu, 'HTML', false, false, true);
}



if($cbdata == "random")
{
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
array(
"text" => "🔄Prossima", 
"callback_data" => "aggiorna"),
);
$array = array(
"Guida da te la tua canoa",
"...nessun profumo vale l'odore di quel fuoco...",
"Essere buoni è qualche cosa, fare il bene è molto meglio",
"Un sorriso fa fare il doppio di strada di un brontolio",
"Quando sei a corto di idee, risparmia il cervello e serviti delle orecchie...",
"Sforzati sempre di vedere ciò che splende dietro le nuvole più nere...",
"Più contempli un pericolo, meno ti piacerà.
Affrontalo con decisione e ti accorgerai che non è poi così brutto come sembra",
"'Andiamo', non 'vai', se vuoi che un lavoro sia fatto...",
"Gioca, non stare a guardare",
"Gioca nella squadra di Dio!",
"L'uomo che è cieco alle bellezze della natura ha perduto metà del piacere di vivere",
"Se sei un piolo quadrato, datti da fare per trovare un buco quadrato!",
"...le stelle sono là, molto al di sopra dei comignoli delle case...",
"Un viso sveglio e sorridente rallegra coloro che lo incontrano...",
"...rinfresca periodicamente la tua conoscenza della Legge...",
);
shuffle($array);
$testo_casuale = $array[0];
cb_reply($cbid, "🍁Frasi di Baden Powell", false, $cbmid, "<b>Citazione di Baden Powell</b>:

<i>$testo_casuale</i>", $menu, 'HTML', false, false, true);
}



if($cbdata == "aggiorna")
{
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
array(
"text" => "🔄Prossima", 
"callback_data" => "aggiorna"),
);
$array = array(
"Guida da te la tua canoa",
"...nessun profumo vale l'odore di quel fuoco...",
"Essere buoni è qualche cosa, fare il bene è molto meglio",
"Un sorriso fa fare il doppio di strada di un brontolio",
"Quando sei a corto di idee, risparmia il cervello e serviti delle orecchie...",
"Sforzati sempre di vedere ciò che splende dietro le nuvole più nere...",
"Più contempli un pericolo, meno ti piacerà.
Affrontalo con decisione e ti accorgerai che non è poi così brutto come sembra",
"'Andiamo', non 'vai', se vuoi che un lavoro sia fatto...",
"Gioca, non stare a guardare",
"Gioca nella squadra di Dio!",
"L'uomo che è cieco alle bellezze della natura ha perduto metà del piacere di vivere",
"Se sei un piolo quadrato, datti da fare per trovare un buco quadrato!",
"...le stelle sono là, molto al di sopra dei comignoli delle case...",
"Un viso sveglio e sorridente rallegra coloro che lo incontrano...",
"...rinfresca periodicamente la tua conoscenza della Legge...",
);
shuffle($array);
$testo_casuale = $array[0];
cb_reply($cbid, "🔄Aggiornamento", false, $cbmid, "<b>Citazione di Baden Powell</b>:

<i>$testo_casuale</i>", $menu, 'HTML', false, false, true);
}



if($cbdata == "introduzione")
{
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "📕Introduzione", false, $cbmid, "Il movimento <b>scout e guide</b> in Italia è presente con più di 70 differenti associazioni e federazioni (ma contando anche quelle non più esistenti si supera il centinaio) aventi circa <b>220.000 aderenti</b>

Insieme a Germania, Francia e Russia, <b>l'Italia è il paese con il movimento scout più frammentato</b>", $menu, 'HTML', false, false, true);
}



if($cbdata == "Indietro")
{
$menu[] = array(
array(
"text" => "📕 Introduzione",
"callback_data" => "introduzione"),
array(
"text" => "🕯Promessa",
"callback_data" => "promessa"),
array(
"text" => "📚 Legge",
"callback_data" => "legge"),
);
$menu[] = array(
array(
"text" => "🍁Frasi Baden Powell",
"callback_data" => "random"),
array(
"text" => "Inline mode",
"switch_inline_query" => ""),
);
cb_reply($cbid, "🏠 Menù", false, $cbmid, "<b>Ciao $nome!</b>
Benvenuto nel primo bot di <i>Telegram Italia</i> riguardante lo <b>scautismo</b>!🌳

Usa questo semplice menù per comunicare con me

Se ti vuoi confrontare con altri <b>scout e guide</b> entra nel <a href=\"https://t.me/joinchat/CWuKjEAaozkj7jV1v-MI4w\">gruppo ufficiale</a>👥

Attualmente sono iscritti al bot <b>$cp scouts</b>", $menu, 'HTML', false, false, true);
}


