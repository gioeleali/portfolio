<?php

echo "<br>Plugin Inline: 1.0";

if($update["inline_query"])
{
$inline = $update["inline_query"]["id"];
$msg = $update["inline_query"]["query"];
$userID = $update["inline_query"]["from"]["id"];
$username = $update["inline_query"]["from"]["username"];
$name = $update["inline_query"]["from"]["first_name"];


$ciao = array(
"Guida da te la tua canoa",
"...nessun profumo vale l'odore di quel fuoco...",
"Essere buoni è qualche cosa, fare il bene è molto meglio",
"Un sorriso fa fare il doppio di strada di un brontolio",
"Quando sei a corto di idee, risparmia il cervello e serviti delle orecchie...",
"Sforzati sempre di vedere ciò che splende dietro le nuvole più nere...",
"Più contempli un pericolo, meno ti piacerà.
Affrontalo con decisione e ti accorgerai che non è poi così brutto come sembra",
"'Andiamo', non 'vai', se vuoi che un lavoro sia fatto...",
"Gioca, non stare a guardare",
"Gioca nella squadra di Dio!",
"L'uomo che è cieco alle bellezze della natura ha perduto metà del piacere di vivere",
"Se sei un piolo quadrato, datti da fare per trovare un buco quadrato!",
"...le stelle sono là, molto al di sopra dei comignoli delle case...",
"Un viso sveglio e sorridente rallegra coloro che lo incontrano...",
"...rinfresca periodicamente la tua conoscenza della Legge...",
);
shuffle($ciao);
$testocasuale = $ciao[0];

$json = array(
//prima riga risultati
array(
'type' => 'article',
'id' => 'kakfieokakfieofo',
'title' => '🍁Frasi Random Baden Powell',
'description' => "Clicca qui per vedere alcune frasi di Baden Powell, verranno mandate in maniera del tutto casuale🌳",
'message_text' => "*Baden Powell dice*☝️🏻

'$testocasuale'",
'thumb_url' => 'https://gioie24.altervista.org/scoutbot/immagine.png',
'parse_mode' => 'Markdown'
),
//altre righe eventuali
);




$json = json_encode($json);
$args = array(
'inline_query_id' => $inline,
'results' => $json,
'cache_time' => 5,
'switch_pm_text' => 'Avviami in privata!',
'switch_pm_parameter' => 'inline'
);
$r = new HttpRequest("post", "https://api.telegram.org/$api/answerInlineQuery", $args);

}



