<?php






//comandi del bot

if($msg == "/start")
{
$menu[] = array( 
array(
"text" => "Post!📷", 
"callback_data" => "Materiale"),
);
sm($chatID, "Ciao <b>$nome</b>!
Benvenuto in @FreePostRobot, questo bot ti permetterà di <i>postare liberamente immagini</i> su <a href='https://t.me/joinchat/AAAAAEjUAq399PmfIYPD7A'>FreePost Channel</a>, per iniziare clicca '<b>Post!</b>'

Un progetto di @Gianluca_C rimesso in vita da @gioeleali.", $menu, 'HTML', false, false, true); 
}

$photo = $update["message"]["photo"][0]["file_id"];

if($cbdata == "Materiale") 
{  
$menu[] = array(  
array(  
"text" => "Annulla↩",  
"callback_data" => "Indietro"),  
); 
cb_reply($cbid, "Free Post!", false, $cbmid, "Ciao <b>$nome</b>!
Benvenuto in @FreePostRobot, questo bot ti permetterà di <i>postare liberamente immagini</i> su <a href='https://t.me/joinchat/AAAAAEjUAq399PmfIYPD7A'>FreePost Channel</a>, per iniziare clicca '<b>Post!</b>'

Un progetto di @Gianluca_C rimesso in vita da @gioeleali.

⚠️<i>Non è consentito pubblicare materiale pornografico e foto contenenti spam.</i>

<i>Adesso invia l'immagine da pubblicare!</i>", $menu, 'HTML', false, false, true);
mkdir("attesa");
mkdir("attesa/foto");
file_put_contents("attesa/foto/$userID.txt","attesa");
}


if($photo and file_exists("attesa/foto/$userID.txt"))
{
if($username)
{
$caption = "@$username";
}else{
$caption = "<a href=\"tg://user?id=$userID\">$nome</a>";
}
$args = array(
'chat_id' => "-1001221853869",
'photo' => $photo,
'parse_mode' => HTML, 
'caption' => "Da $caption.",
);
new HttpRequest("get", "https://api.telegram.org/$api/sendPhoto", $args);

$menu[] = array(
array(
"text" => "Home🏠",
"callback_data" => "Indietro"),
);
sm($chatID, "<b>Immagine pubblicata!</b>📸", $menu, 'HTML', false, false, true);

unlink("attesa/foto/$userID.txt");
}

if($cbdata == "Indietro")
{
unlink("attesa/foto/$userID.txt");
}


if($cbdata == "Indietro")
{
$menu[] = array(
array( 
"text" => "Post!📷", 
"callback_data" => "Materiale"),
);
cb_reply($cbid, "Menù principale.", false, $cbmid, "Ciao <b>$nome</b>!
Benvenuto in @FreePostRobot, questo bot ti permetterà di <i>postare liberamente immagini</i> su <a href='https://t.me/joinchat/AAAAAEjUAq399PmfIYPD7A'>FreePost Channel</a>, per iniziare clicca '<b>Post!</b>'

Un progetto di @Gianluca_C rimesso in vita da @gioeleali.", $menu, 'HTML', false, false, true);
}

if($msg == "/chatid")
{
sm($chatID, "$chatID");
}











