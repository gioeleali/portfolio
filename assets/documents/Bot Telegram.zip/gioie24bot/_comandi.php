<?php

if($msg == "/start")
{
$menu[] = array(
array( 
"text" => "👥 Gruppo", 
"url" => "http://telegram.me/MinecraftGruppo"),
array(
"text" => "📢 Canale", 
"url" => "http://telegram.me/Minecraft_Italia"),
);
$menu[] = array(
array(
"text" => "🔭 Network", 
"url" => "http://telegram.me/GameNetwork"),
);
sm($chatID, "<b>Benvenuto $nome</b>!
Con questo Bot puoi parlare con @Gioie24

<i>Scrivimi qui un messaggio che vuoi inviare e io ti risponderò appena possibile!</i>👌🏻", $menu, 'HTML', false, false, true); 
}
