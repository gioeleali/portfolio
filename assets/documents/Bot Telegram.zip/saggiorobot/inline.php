<?php

echo "<br>Plugin Inline: 1.0";

if($update["inline_query"])
{
$inline = $update["inline_query"]["id"];
$msg = $update["inline_query"]["query"];
$userID = $update["inline_query"]["from"]["id"];
$username = $update["inline_query"]["from"]["username"];
$name = $update["inline_query"]["from"]["first_name"];

$saggio = str_replace("?", "", $msg);
$google = str_replace(" ", "+", $msg);
$qcp = mysql_query("select * from $tabella where not page = 'disable' and chat_id>0 group by chat_id");
$cp = mysql_num_rows($qcp);

$array = array(
"Pensa di meritare risposta? Sono il Grande Saggio, veda un po' lei.",
"Ovviamente si.",
"Sicuramente si.",
"È scontata come risposta.",
"Si, senza alcun dubbio.",
"Ma che domande sono, suvvia.",
"Penso proprio di no.",
"Rispondo di no senza nemmeno pensarci.",
"Figliolo, guardati attorno e risponditi da solo.",
"Ovviamente no.",
"Sì.",
"No.",
"$name, certe domande neanche si fanno.",
"Secondo me si, poi voi lo sapete meglio di me.",
"Secondo me no, poi voi lo sapete meglio di me.",
"Certamente.",
"Questa è una domanda difficile, anche essendo il Grande Saggio ho avuto difficoltà a rispondere, sono comunque giunto ad una conclusione: la risposta è no.",
"Questa è una domanda difficile, anche essendo il Grande Saggio ho avuto difficoltà a rispondere, sono comunque giunto ad una conclusione: la risposta è si.",
"La risposta giusta è quella che pensi te.",
"A giudicare dal tempo penso proprio di si.",
"Assolutamente no.",
"Immagina di essere me: cosa risponderesti?
Ovviamente nulla perché non potrai mai avere la mia stessa saggezza. 
Comunque no, assolutamente no.",
"Mh, si dai.",
"Per il 56% è si, per il 44% è no.",
"Non rispondo. Codesta è una domanda stupida.",
"Neanche io so rispondere a questa domanda, prova a chiedere al [Mr.Google](http://google.com/search?q=$google), lui sa quasi tutto.",
"A giudicare dalle tue scarse capacità intellettive dico di no.",
"Porca puttana me lo chiedi anche?",
"Evidentemente si.",
"Evidentemente no.",
"Vai dalla persona più vicina a te e ripetigli questa domanda, saprà darti la risposta corretta.",
"Non ti vergogni a chiedere una cosa del genere?",
"Non è il momento, sono in una situazione complicata.",
"Non posso parlare, sono al 28 giorno della Blue Whale.",
"$name, non rispondo ai ritardati.",
"$name per oggi hai finito le tue domande giornaliere, da ora vengono 1€ l'una.",
"_Porca troia_ aspetta un secondo che mi sta morendo il gatto.",
"Ti posso dare la risposta desiderata solo in cambio di denaro. Il tutto viene 5€ IVA inclusa.",
"Sono in una fase di riflessione profonda, richiamami più tardi.",
"Oggi mi sono svegliato stronzo, non ti voglio rispondere",
"CENTOOOODICIOOOTTOOOOO!",
"$name, con $cp seguaci a cui star dietro secondo te ho il tempo di risponderti?",
"La risposta è...   ...un secondo, hai un nuovo messaggio!

ℹTIM: Abbiamo deciso di applicare nuove tariffe per le chiamate proporzionate alla lunghezza del pene. Complimenti. Per te il servizio è gratis!",
"Potrebbe essere entrambe le risposte.",
"Con quella faccia no a prescindere.",
"Le rose sono rosse, le viole sono blu, la risposta alla domanda è quella che sai tu.",
"Applicando il Teorema di Pitagora alla tua domanda si può calcolare una risposta ben precisa, ovvero sì.",
"No no grazie, non compro nulla.",
"SALUTA 'NDONIO!",
"Error 404.",
"Il rumore delle foglie mi suggerisce il sì.",
"Madre Natura mi ispira un NO profondo.",
"In questo caso la risposta corretta la può dare solo @durov7.",
"Guarda l'orario. Prendi i minuti. Somma le due cifre. Se la somma è pari la risposta sarà si, se è dispari sarà no.",
"💤💤...

ℹTIM: Il Saggio da lei evocato non è al momento disponibile, la preghiamo di riprovare più tardi, grazie!",
"Credo di saperlo, ma non mi sembra una risposta adatta ad una persona come te.",
"$name sarei tentato di prendermela con il tuo cervello ma l'educazione che ho ricevuto mi impedisce di parlar male degli assenti."
);
shuffle($array);
$testo_casuale = $array[0];

if($saggio == null)
{
$saggio = "Sono un po' ritardato";
{
$testo_casuale = "Evidentemente si dato che non hai messo nessuna domanda deficiente.";
}
}


$json = array(
//prima riga risultati
array(
'type' => 'article',
'id' => 'kakfieokakfieofo',
'title' => '❔Dichiara la tua domanda',
'description' => "❓Premendo qui saprai la risposta alla seguente domanda: '$saggio?'",
'message_text' => "👦🏻Tu: *$saggio?*

👳🏽Saggio: $testo_casuale",
'parse_mode' => 'Markdown',
'disable_web_page_preview' => true,
'thumb_url' => 'https://gioie24.altervista.org/saggiorobot/banned.jpg'
),
);




$json = json_encode($json);
$args = array(
'inline_query_id' => $inline,
'results' => $json,
'cache_time' => 5,
'switch_pm_text' => 'Chat privata⤵',
'switch_pm_parameter' => 'inline'
);
$r = new HttpRequest("post", "https://api.telegram.org/$api/answerInlineQuery", $args);

}






