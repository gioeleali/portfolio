<?php
//comandi del bot

$qcp = mysql_query("select * from $tabella where not page = 'disable' and chat_id>0 group by chat_id");
$cp = mysql_num_rows($qcp);

if($msg == "/start" or $msg == "/start inline")
{
$menu[] = array(
array(
"text" => "Inline Mode",
"switch_inline_query" => ""),
);
sm($chatID, "<b>Ciao $nome!</b>
Questo bot funziona solo inline, ti basterà scrivere in una qualsiasi chat:
<code>@saggiorobot la tua domanda</code>
dove <code>la tua domanda</code> sarà la domanda rivolta al <b>Grande Saggio</b>.
Posso dare solo risposte secche.
Il <b>Grande Saggio</b> attualmente ha<b> $cp discepoli</b>

🌟<b>Ti piace il bot?</b>
Votalo su storebot, bastano <b>10 secondi</b>! <a href=\"http://telegram.me/storebot?start=SaggioRobot\">Clicca qui</a>.", $menu, 'HTML', false, false, true);
}

if($msg == "/chatid")
{
sm($chatID, "$chatID");
}