<?php






//comandi del bot


if($msg == "/start")
{
$menu[] = array(
array(
"text" => "📖 Help",
"callback_data" => "help"),
array(
"text" => "Inline mode",
"switch_inline_query_current_chat" => ""),
);
sm($chatID, "<b>Welcome!
Thanks</b> you very much for starting <b>me</b>!
<b>How use me</b>? Click '📖 Help'!
Do you need more <b>help</b>? Contact me! @Gioie24", $menu, 'HTML', false, false, true);
}



if($cbdata == "help")
{
$menu[] = array( 
array( 
"text" => "🏠 Menù", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "📖 Help", false, $cbmid, "<b>How to use this bot?
Server command</b>
Within this command, you can search for a <b>Minecraft server</b>

Usage: <code>/mcpc server-ip</code>
The port it's set by <b>default</b> on <code>25565</code>
Example: <code>/mcpc pair.masfik.net</code>

Usage: <code>/mcpe server-ip</code>
The port it's set by <b>default</b> on <code>19132</code>
Example: <code>/mcpe sg.lbsg.net</code>

More commands will added soon, stay tuned!

<b>Thanks for the support!</b>
You can vote the bot <a href=\"http://telegram.me/storebot?start=MinecraftServersRobot\">clicking here</a>, takes a few seconds

Developer: @Gioie24 & @PietroArado", $menu, 'HTML', false, false, true);
}



if($cbdata == "Indietro")
{
$menu[] = array(
array(
"text" => "📖 Help",
"callback_data" => "help"),
array(
"text" => "Inline mode",
"switch_inline_query_current_chat" => ""),
);
cb_reply($cbid, "🏠 Menù", false, $cbmid, "<b>Welcome!
Thanks</b> you very much for starting <b>me</b>!
<b>How use me</b>? Click '📖 Help'!
Do you need more <b>help</b>? Contact me! @Gioie24", $menu, 'HTML', false, false, true);
}

if($msg == "/start inline")
{
sm($chatID, "<b>Inline tutorial</b>
This bot it's inline, too!
<a href=\"https://core.telegram.org/bots/inline\">Inline? What does it mean?</a>
<b>Search Minecraft Servers in any chat:</b> 
<code>@MinecraftServersRobot server-ip</code>");
}

if(strpos($msg, "/mcpc")===0)
{
$e = explode(" ", $msg, 2);
$text = $e[1];
if($text)
{
$var = file_get_contents("https://mcapi.ca/query/" . $text . "/info");
$decodifica = json_decode($var, true);
$versions = $decodifica["version"];
$status = $decodifica["status"];
$players = $decodifica["players"];
$online = $players["online"];
$max = $players["max"];
$port = $decodifica["port"];
$ping = $decodifica["ping"];
$protocol = $decodifica["protocol"];
$hostname = $decodifica["hostname"];
if($status)
{
$status = "Online!";
}
sm($chatID, "<a href=\"https://use.gameapis.net/mc/query/banner/$text:$port\">✅</a><b>$status</b>
<b>IP</b>: $hostname (<code>$online/$max</code>)
<b>Port</b>: $port
<b>Ping</b>: $ping
<b>Protocol</b>: <i>$protocol</i>
<b>Version</b>: $versions ");
}
}
