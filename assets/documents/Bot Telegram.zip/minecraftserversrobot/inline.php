<?php

echo "<br>Plugin Inline: 1.0";

if($update["inline_query"])
{
$inline = $update["inline_query"]["id"];
$msg = $update["inline_query"]["query"];
$userID = $update["inline_query"]["from"]["id"];
$username = $update["inline_query"]["from"]["username"];
$name = $update["inline_query"]["from"]["first_name"];

$var = file_get_contents("https://mcapi.ca/query/" . $msg . "/info");
$vardue = file_get_contents("https://mcapi.ca/query/" . $msg . "/status");
$decodifica = json_decode($var, true);
$decodificadue = json_decode($vardue, true);
$players = $decodifica["players"];
$online = $players["online"];
$max = $players["max"];
$status = $decodifica["status"];
$versions = $decodifica["version"];
$port = $decodifica["port"];
$ping = $decodificadue["ping"];
if($status)
{
$status = "✅Online!";
}
if(!$status)
{
$status = "🔴Offline!";
}


$json = array(
//prima riga risultati
array(
'type' => 'article',
'id' => 'kakfieokakfieofo',
'title' => 'Server MCPC Info',
'description' => "Write a server IP here",
'message_text' => "*$status*
*IP*: $msg (`$online/$max`)
*Port*: $port
*Ping*: $ping
*Version*: $versions",
'parse_mode' => 'Markdown',
'thumb_url' => 'https://gioie24yt.altervista.org/minecraftserversrobot/banner.png'
),
);




$json = json_encode($json);
$args = array(
'inline_query_id' => $inline,
'results' => $json,
'cache_time' => 5,
'switch_pm_text' => 'Need help? Click here!',
'switch_pm_parameter' => 'inline'
);
$r = new HttpRequest("post", "https://api.telegram.org/$api/answerInlineQuery", $args);

}



