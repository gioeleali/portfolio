<?php

echo "<br>Plugin Inline: 1.0";

if($update["inline_query"])
{
$inline = $update["inline_query"]["id"];
$msg = $update["inline_query"]["query"];
$userID = $update["inline_query"]["from"]["id"];
$username = $update["inline_query"]["from"]["username"];
$name = $update["inline_query"]["from"]["first_name"];

$google = str_replace(" ", "+", $msg);

$tastiera[] = array(
array(
"text" => "🤓 Ricerca Ignorante",
"url" => "http://google.com/search?q=$google"
)
);

$csi = array(
'inline_keyboard' => $tastiera);



$json = array(
//prima riga risultati
array(
'type' => 'article',
'id' => 'kakfieokakfieofo',
'title' => '📖 Coltivando Si Impara',
'description' => "🔍Ricerca ignorante per contadini ignoranti, che, coltivando, producono materie prime ignoranti",
'message_text' => "Ecco la *ricerca ignorante* della _seguente parola/frase_:
'*$msg*'",
'reply_markup' => $csi,
'thumb_url' => 'http://gioie24.altervista.org/coltivandosimparabot/immagine.jpg',
'parse_mode' => 'Markdown'
),
);




$json = json_encode($json);
$args = array(
'inline_query_id' => $inline,
'results' => $json,
'cache_time' => 5,
'switch_pm_text' => 'Ehy contadino! Avviami in privata!',
'switch_pm_parameter' => 'csi'
);
$r = new HttpRequest("post", "https://api.telegram.org/$api/answerInlineQuery", $args);

}






