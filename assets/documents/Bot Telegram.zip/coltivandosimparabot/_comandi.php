<?php






//comandi del bot


if($msg == "/start" or $msg == "/start csi")
{
$menu[] = array( 
array( 
"text" => "📬 Inviaci materiale", 
"callback_data" => "Materiale"),
array(
"text" => "🗣 Parla con me",
"callback_data" => "Chatta"),
);
$menu[] = array(
array(
"text" => "✒ Richiesta sponsor",
"callback_data" => "Sponsor"),
array(
"text" => "🔢 Membri canale",
"callback_data" => "Membri"),
);
$menu[] = array(
array( 
"text" => "👥 Coltivando Si Ignora 2.0", 
"url" => "https://telegram.me/joinchat/CBi32kEMCeNBIU52HKQGlQ"),
);
$menu[] = array(
array( 
"text" => "📢 ColtivandoSimpara", 
"url" => "http://telegram.me/ColtivandoSimpara"),
);
sm($chatID, "<b>Ciao $nome</b>!
<b>Benvenuto in</b> @ColtivandoSimparaBot!

Con questo <b>piccolo menù</b> potrai darci <b>suggerimenti</b> e <b>inviarci materiale</b> per il canale!😉", $menu, 'HTML', false, false, true); 
}


$cbmidni = $update['message']['message_id'];
$photo = $update["message"]["photo"][0]["file_id"];

if($cbdata == "Materiale") 
{ 
$menu[] = array(  
array(  
"text" => "❌Annulla",  
"callback_data" => "Indietro"),  
); 
cb_reply($cbid, "📬 Inviaci materiale!", false, $cbmid, "Adesso invia il <b>materiale</b> che vuoi proporci, esso verrà <i>esaminato dal gruppo staff</i> e, se ritenuto adatto per il canale,<i> verrà postato</i>.
 
Se vuoi essere <b>citato nel canale</b> invia <i>come descrizione</i> alla foto il tuo <b>username</b>.
Per impostare un username vai su: 
<code>'Impostazioni' > 'Profilo' > 'Username'</code>

⚠️<b>Attenzione:</b> qualsiasi abuso di questo comando comporterà il <b>ban immediato</b> dal bot.
Quindi, <i>prima di agire</i>, pensa.", $menu, 'HTML', false, false, true);
mkdir("attesa");
mkdir("attesa/foto");
file_put_contents("attesa/foto/$userID.txt","attesa");
}


if($photo and file_exists("attesa/foto/$userID.txt"))
{
$args = array(
'chat_id' => "-1001111257492",
'from_chat_id' => $userID,
'message_id' => $cbmidni,
);
new HttpRequest("get", "https://api.telegram.org/$api/forwardMessage", $args);

$menu[] = array(
array(
"text" => "📬 Invia ancora",
"callback_data" => "Materiale"),
);

$menu[] = array(
array(
"text" => "❌Indietro",
"callback_data" => "Indietro"),
);
sm($chatID, "<b>Foto inviata con successo allo staff✅</b>

Se hai <i>altre immagini interessanti</i>, clicca su '<b>invia ancora</b>'.", $menu, 'HTML', false, false, true);

unlink("attesa/foto/$userID.txt");
}

if($cbdata == "Indietro")
{
unlink("attesa/foto/$userID.txt");
}


if($cbdata == "Chatta")
{
$menu[] = array( 
array( 
"text" => "❌Indietro", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "🗣 Parla con me", false, $cbmid, "Per mandare un messaggio a <b>SekMeteor</b> usa il seguente formato:
<code>/msg testo da inviare</code>.

Ti risponderà il più presto possibile, <b>anche lui ha una vita</b>, devi saper aspettare.

<i>Qualsiasi abuso</i> di questo comando comporterà il <b>ban immediato</b> dal bot.", $menu, 'HTML', false, false, true);
}

if($cbdata == "Sponsor")
{
$menu[] = array(
array(
"text" => "1⃣ Sponsor minimo 8K",
"callback_data" => "sponsor1"),
);
$menu[] = array(
array(
"text" => "2⃣ Sponsor a pagamento",
"callback_data" => "sponsor2"),
);
$menu[] = array( 
array( 
"text" => "❌Indietro", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "✒ Richiedi sponsor", false, $cbmid, "Desideri uno <b>sponsor normale con minimo 8K</b> o uno <b>sponsor a pagamento</b>?", $menu, 'HTML', false, false, true);
}



if($cbdata == "Indietro2")
{
$menu[] = array(
array(
"text" => "1⃣ Sponsor minimo 8K",
"callback_data" => "sponsor1"),
);
$menu[] = array(
array(
"text" => "2⃣ Sponsor a pagamento",
"callback_data" => "sponsor2"),
);
$menu[] = array( 
array( 
"text" => "❌Indietro", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "✒ Richiedi sponsor", false, $cbmid, "Desideri uno <b>sponsor normale con minimo 8K</b> o uno <b>sponsor a pagamento</b>?", $menu, 'HTML', false, false, true);
}


$cbmidni = $update['message']['message_id'];

if($cbdata == "sponsor1")
{
$menu[] = array( 
array( 
"text" => "❌Indietro", 
"callback_data" => "Indietro2"), 
);
cb_reply($cbid, "🍬 Sponsor normale", false, $cbmid, "Ricorda, il canale deve rispettare i seguenti punti:

• <b>deve avere minimo 8K di utenti</b> <i>(per gli ignoranti 8K = 8000)</i>
• <b>non deve essere un canale gore</b>
• <b>non deve essere inattivo</b>

Affinché la <b>richiesta venga accettata</b> deve rispettare <b>tutti e 3 i punti</b>.

<i>Se abusi</i> di questo comando verrai <b>bannato immediatamente</b> dal bot.

Ora manda il <i>link o l'username</i> del tuo canale.", $menu, 'HTML', false, false, true);
mkdir("attesa");
mkdir("attesa/foto");
file_put_contents("attesa/foto/$userID.txt","attesa");
}

if($cbmidni and file_exists("attesa/foto/$userID.txt"))
{
$args = array(
'chat_id' => "-1001107920972",
'from_chat_id' => $userID,
'message_id' => $cbmidni,
);
new HttpRequest("get", "https://api.telegram.org/$api/forwardMessage", $args);

$menu[] = array(
array(
"text" => "❌Indietro",
"callback_data" => "Indietro"),
);
sm($chatID, "<b>Richiesta di sponsor  inviata con successo a SekMeteor</b>✅", $menu, 'HTML', false, false, true);

unlink("attesa/foto/$userID.txt");
}

if($cbdata == "Indietro")
{
unlink("attesa/foto/$userID.txt");
}


$cbmidni = $update['message']['message_id'];

if($cbdata == "sponsor2")
{
$menu[] = array( 
array( 
"text" => "❌Indietro", 
"callback_data" => "Indietro2"), 
);
cb_reply($cbid, "💶 Sponsor a pagamento", false, $cbmid, "<i>Listino prezzi:</i>
• <b>0,50€ all'ora per un massimo di 8 ore</b>

<i>Se abusi</i> di questo comando verrai <b>bannato immediatamente</b> dal bot.

Invia <i>il link o l'username</i> del tuo canale e quante <b>ore di sponsor vuoi fare</b>, tutto in un unico messaggio.", $menu, 'HTML', false, false, true);
mkdir("attesa");
mkdir("attesa/foto");
file_put_contents("attesa/foto/$userID.txt","attesa");
}

if($cbmidni and file_exists("attesa/foto/$userID.txt"))
{
$args = array(
'chat_id' => "-1001107920972",
'from_chat_id' => $userID,
'message_id' => $cbmidni,
);
new HttpRequest("get", "https://api.telegram.org/$api/forwardMessage", $args);

$menu[] = array(
array(
"text" => "❌Indietro",
"callback_data" => "Indietro"),
);
sm($chatID, "<b>Richiesta di sponsor a pagamento inviata con successo a SekMeteor</b>✅", $menu, 'HTML', false, false, true);

unlink("attesa/foto/$userID.txt");
}

if($cbdata == "Indietro")
{
unlink("attesa/foto/$userID.txt");
}



$canale = json_decode(file_get_contents ("https://api.telegram.org/$api/getchatmemberscount?chat_id=@coltivandosimpara"), true);
$membri = $canale['result'];

if($cbdata == "Membri")
{
$menu[] = array( 
array( 
"text" => "❌Indietro", 
"callback_data" => "Indietro"), 
);
cb_reply($cbid, "🔢 Membri canale", false, $cbmid, "<i>Membri attuali del canale</i> @ColtivandoSimpara<i>:</i> <b>$membri membri!</b>", $menu, 'HTML', false, false, true);
}



if($cbdata == "Indietro")
{
$menu[] = array( 
array( 
"text" => "📬 Inviaci materiale", 
"callback_data" => "Materiale"),
array(
"text" => "🗣 Parla con me",
"callback_data" => "Chatta"),
);
$menu[] = array(
array(
"text" => "✒ Richiesta sponsor",
"callback_data" => "Sponsor"),
array(
"text" => "🔢 Membri canale",
"callback_data" => "Membri"),
);
$menu[] = array(
array( 
"text" => "👥 Coltivando Si Ignora 2.0", 
"url" => "https://telegram.me/joinchat/CBi32kEMCeNBIU52HKQGlQ"),
);
$menu[] = array(
array( 
"text" => "📢 ColtivandoSimpara", 
"url" => "http://telegram.me/ColtivandoSimpara"),
);
cb_reply($cbid, "🏠 Menù principale", false, $cbmid, "Sei tornato al <b>menù principale</b>.

Con questo <b>piccolo menù</b> potrai darci <b>suggerimenti</b> e <b>inviarci materiale</b> per il canale!😉", $menu, 'HTML', false, false, true);
}


//inoltro

$cbmidni = $update['message']['message_id'];
$photo = $update["message"]["photo"][0]["file_id"];

if($photo)
{
$args = array(
'chat_id' => $chatID,
'from_chat_id' => -1001056617326,
'message_id' => $cbmidni,
);
new HttpRequest("get", "https://api.telegram.org/$api/forwardMessage", $args);
}








