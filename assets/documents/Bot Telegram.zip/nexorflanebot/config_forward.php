﻿<?php

//	Configurazione del plugin Forward

//	Creato da @xSamumine
//	Distribuito da @AVPlugin

$canale = "-1001114301038";	