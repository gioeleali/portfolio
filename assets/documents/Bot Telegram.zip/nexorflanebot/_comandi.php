<?php






//comandi del bot


if($msg == "/start")
{
sm($chatID, "Ciao, sono il bot di @NexOrFlane!
Il mio compito è quello di <b>inoltrare in tutti i gruppi in cui vengo aggiunto</b> i link dei video di NexOrFlane.

⚠️<i>Ci potrebbero volere alcuni giorni prima che il bot inizi a inoltrare i messaggi nel gruppo</i>

<i>Info:</i> @gioeleali");
}

if($msg == "/chatid")
{
sm($chatID, "$chatID");
}


